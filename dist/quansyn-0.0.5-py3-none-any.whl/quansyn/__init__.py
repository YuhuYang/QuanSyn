__all__ = ["depval","lawfitter","lingnet"]
__version__ = "0.0.5"